﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using System.Data.SqlClient;


// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace Login
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class NewUser : Page
    {
        public NewUser()
        {
            this.InitializeComponent();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            const string myConnection=@"Server=LAPTOP-3N9BP55C;Database=[Fantasy Football Generator];Trusted_Connection=True;";
            using (var con = new SqlConnection(myConnection)) 

            {
                SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[User Info]([UserName] ,[Age],[Email],[FirstName],[LastName],[MiddleName])");
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@FirstName", FirstName.Text);
                cmd.Parameters.AddWithValue("@LastName", LastName.Text);
                cmd.Parameters.AddWithValue("@MiddleName", MiddleName.Text);
                cmd.Parameters.AddWithValue("@UserName", UserName.Text);
                cmd.Parameters.AddWithValue("@Password", PassWord.Text);
                cmd.Parameters.AddWithValue("@Email", Email.Text);
                cmd.Parameters.AddWithValue("@Age", Age.Text);
                con.Open();
                int i = cmd.ExecuteNonQuery();

                con.Close();
            }
            //SqlConnection con = new SqlConnection(myConnection);


            //SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[User Info]([UserName] ,[Age],[Email],[FirstName],[LastName],[MiddleName])", con);

            //cmd.CommandType = System.Data.CommandType.StoredProcedure;
            //cmd.Parameters.AddWithValue("@FirstName", FirstName.Text);
            //cmd.Parameters.AddWithValue("@LastName", LastName.Text);
            //cmd.Parameters.AddWithValue("@MiddleName", MiddleName.Text);
            //cmd.Parameters.AddWithValue("@UserName", UserName.Text);
            //cmd.Parameters.AddWithValue("@Password", PassWord.Text);
            //cmd.Parameters.AddWithValue("@Email", Email.Text);
            //cmd.Parameters.AddWithValue("@Age", Age.Text);
            //con.Open();
            //int i = cmd.ExecuteNonQuery();

            //con.Close();

        }
    }
}
