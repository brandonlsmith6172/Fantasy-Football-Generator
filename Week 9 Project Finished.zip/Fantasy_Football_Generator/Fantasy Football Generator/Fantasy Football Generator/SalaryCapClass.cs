﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login
{
    public class SalaryCapClass : INotifyPropertyChanged
    {
        public int SalaryCap { get; set; }
       
        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        public ObservableCollection<User_Info> GetUser_Info(string connectionString)
        {
            const string GetProductsQuery = "Select SalaryCap" +
                "from SavedRosters";
            var userInfo = new ObservableCollection<User_Info>();
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    if (conn.State == System.Data.ConnectionState.Open)
                    {
                        using (SqlCommand cmd = conn.CreateCommand())
                        {
                            cmd.CommandText = GetProductsQuery;
                            using (SqlDataReader reader = cmd.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    var newroster = new playerCost();
                                    newroster.PlayerID = reader.GetInt32(0);
                                    newroster.PlayerName = reader.GetString(1);
                                    newroster.PlayerSalary = reader.GetInt32(2);
                                }
                            }
                        }
                    }
                }
                return userInfo;
            }
            catch (Exception eSql)
            {
                Debug.WriteLine("Exception: " + eSql.Message);
            }
            return null;
        }
    }
}

