﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Diagnostics;

namespace Login
{
    class Login 
    {
        public string UserName { get; set; }
        public bool Btn_Click1(string username)
        {
            UserName = username;
            if (UserName == "")
            {
                return false;
            }
            else if ((UserName == "chris") || (UserName == "brandon") || (UserName == "aj") || (UserName == "anthony") || (UserName == "austin"))
            {
                return true;
            }
            return false;
        }

    }
}
