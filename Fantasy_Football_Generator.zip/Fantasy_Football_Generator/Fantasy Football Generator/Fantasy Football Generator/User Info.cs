﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login
{
    class User_Info : INotifyPropertyChanged
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string UserPassword { get; set; }
        public string Age { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string MiddleName { get; set; }
        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        public ObservableCollection<User_Info> GetUser_Info(string connectionString)
        {
            const string GetProductsQuery = "Select UserID, UserName, UserPassword, Age, Email, FirstName, LastName, MiddleName" +
                "from [User Info]";
            var userInfo = new ObservableCollection<User_Info>();
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    if (conn.State == System.Data.ConnectionState.Open)
                    {
                        using (SqlCommand cmd = conn.CreateCommand())
                        {
                            cmd.CommandText = GetProductsQuery;
                            using (SqlDataReader reader = cmd.ExecuteReader())
                            {
                                while(reader.Read())
                                {
                                    var userinfo = new User_Info();
                                    userinfo.UserID = reader.GetInt32(0);
                                    userinfo.UserName = reader.GetString(1);
                                    userinfo.UserPassword = reader.GetString(2);
                                    userinfo.FirstName = reader.GetString(3);
                                    userinfo.MiddleName = reader.GetString(4);
                                    userinfo.LastName = reader.GetString(5);
                                    userinfo.Email = reader.GetString(7);
                                }
                            }
                        }
                    }
                }return userInfo;
            }
            catch(Exception eSql)
            {
                Debug.WriteLine("Exception: " + eSql.Message);
            }
            return null;
        }
    }
}
