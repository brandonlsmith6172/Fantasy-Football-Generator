﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;


namespace FootballCalc.Tests
{
    public class LoginInfoTests
    {
        [Fact]
        public void CanChangeUserName()
        {
            //Arrange
            //do code work Look on Pg 170 in MVC book

            //Act
            //do code work here

            //Assert
            //do code work here
        }
        [Fact]
        public void CanChangePassword()
        {
            //Arrange
            //do code work Look on Pg 170 in MVC book

            //Act
            //do code work here

            //Assert
            //do code work here
        }
    }
}
