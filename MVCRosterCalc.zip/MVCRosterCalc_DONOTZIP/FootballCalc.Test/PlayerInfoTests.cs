﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace FootballCalc.Tests
{
    public class PlayerInfoTests
    {
        [Fact]
        public void CanChangePlayerName()
        {
            //Arrange
            //do code work Look on Pg 170 in MVC book

            //Act
            //do code work here

            //Assert
            //do code work here
        }
        [Fact]
        public void CanChangePlayerPrice()
        {
            //Aarrange
            //do code work here

            //Act
            //do code work here

            //Assert
            //do code work here
        }

    }
    
}
